<?php

use Illuminate\Database\Seeder;

class PlacementClientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
