<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\TenueCompte;
use Faker\Generator as Faker;

$factory->define(TenueCompte::class, function (Faker $faker) {
    return [
        //
    ];
});
