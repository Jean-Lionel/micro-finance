<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PlacementCompteOperation;
use Faker\Generator as Faker;

$factory->define(PlacementCompteOperation::class, function (Faker $faker) {
    return [
        //
    ];
});
