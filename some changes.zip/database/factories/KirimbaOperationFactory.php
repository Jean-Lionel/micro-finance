<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\kirimbaOperation;
use Faker\Generator as Faker;

$factory->define(kirimbaOperation::class, function (Faker $faker) {
    return [
        //
    ];
});
