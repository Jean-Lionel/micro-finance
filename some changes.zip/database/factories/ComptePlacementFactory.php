<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ComptePlacement;
use Faker\Generator as Faker;

$factory->define(ComptePlacement::class, function (Faker $faker) {
    return [
        //
    ];
});
