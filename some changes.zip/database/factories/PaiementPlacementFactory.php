<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\PaiementPlacement;
use Faker\Generator as Faker;

$factory->define(PaiementPlacement::class, function (Faker $faker) {
    return [
        //
    ];
});
