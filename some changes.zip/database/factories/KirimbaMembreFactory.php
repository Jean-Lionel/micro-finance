<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\KirimbaMembre;
use Faker\Generator as Faker;

$factory->define(KirimbaMembre::class, function (Faker $faker) {
    return [
        //
    ];
});
