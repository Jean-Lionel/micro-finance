<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\CompteClient;
use Faker\Generator as Faker;

$factory->define(CompteClient::class, function (Faker $faker) {
    return [
        //
    ];
});
