<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PlacementClient;
use Faker\Generator as Faker;

$factory->define(PlacementClient::class, function (Faker $faker) {
    return [
        //
    ];
});
