<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\UserAgence;
use Faker\Generator as Faker;

$factory->define(UserAgence::class, function (Faker $faker) {
    return [
        //
    ];
});
