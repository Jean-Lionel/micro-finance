<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Placement;
use Faker\Generator as Faker;

$factory->define(Placement::class, function (Faker $faker) {
    return [
        //
    ];
});
