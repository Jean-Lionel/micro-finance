<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Benefice;
use Faker\Generator as Faker;

$factory->define(Benefice::class, function (Faker $faker) {
    return [
        //
    ];
});
