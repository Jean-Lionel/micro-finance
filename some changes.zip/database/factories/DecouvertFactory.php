<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Decouvert;
use Faker\Generator as Faker;

$factory->define(Decouvert::class, function (Faker $faker) {
    return [
        //
    ];
});
