<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\KirimbaCompte;
use Faker\Generator as Faker;

$factory->define(KirimbaCompte::class, function (Faker $faker) {
    return [
        //
    ];
});
