<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models PlacementCompteOperation;
use Faker\Generator as Faker;

$factory->define(Models PlacementCompteOperation::class, function (Faker $faker) {
    return [
        //
    ];
});
