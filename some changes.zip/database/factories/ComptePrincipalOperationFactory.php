<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\ComptePrincipalOperation;
use Faker\Generator as Faker;

$factory->define(ComptePrincipalOperation::class, function (Faker $faker) {
    return [
        //
    ];
});
