<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Depense;
use Faker\Generator as Faker;

$factory->define(Depense::class, function (Faker $faker) {
    return [
        //
    ];
});
