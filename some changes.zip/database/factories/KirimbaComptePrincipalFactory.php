<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\KirimbaComptePrincipal;
use Faker\Generator as Faker;

$factory->define(KirimbaComptePrincipal::class, function (Faker $faker) {
    return [
        //
    ];
});
