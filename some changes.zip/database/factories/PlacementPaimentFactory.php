<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\placement_paiment;
use Faker\Generator as Faker;

$factory->define(placement_paiment::class, function (Faker $faker) {
    return [
        //
    ];
});
