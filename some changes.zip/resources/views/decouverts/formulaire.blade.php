
<div class="mcontainer" id="print_form">
		<header class="mheader">
			<h3 class="mheader-title">
				<span style="color:green;">COOPERATIVE POUR LE DEVELLOPPEMENT</span>
				 <span style="color:red">INEZA IWACU</span>
				<span style="color: gold;">
					<< COOPDI >>
				</span>
			</h3>
			<div class="green-line"></div>
			<div class="red-line"></div>
			<h4 class="mheader-title"><u>AMASEZERANO YEREKEYE INGURANE</u></h4>
		</header>

		<section class="section">
			<p>
				Hagati ya COOPDI, ishirahamwe ryo kuziganya no kuguranana, rifise icicaro gikuru i Bujumbura muri komine NTAHANGWA, zone ya Kinama kw'ibarabara rya mbere inomero .... <br>


				N'umunywanyi 
				<span class="client_name">
					<b> .....izina ry'umunywanyi ....</b>
				</span> Nyene ikonte inomero 

				<b><span class="client_compte_name">
					<b>........(num de compte)..</b>
				</span></b>
				
				yuguruwe muri COOPDI kw'izina ryiwe

			</p>

			<p>
				<b>Ingingo ya 1 :</b> COOPDI ihaye umunyanwi wayo ingurane ingana n'amafaranga y'amarundi <b contenteditable>.............(amafaranga mumajambo) </b> izokwishurwa mukiringo c'amezi 

				<span class="month_number" contenteditable>
					........(igitigiri c'amezi )
				</span>

				 kuva kw'igenekerezo rya 
				 <span class="start_date" contenteditable>
				 	.........(date du debut) 
				 </span>. 
				 Gushika kw'igenekerezo rya
				  <span class="end_date">
				 	... date de fin ...
				 </span> biciye kuri konte yiwe no <span class="client_compte_name"> Numero de compte </span>. yuguruwe muri COOPDI . Iyi ngurane itegekanijwe kurangura ibikorwa vyiwe vy'ubudandaji akaba atarekuriwe kuyikoresha ibindi.
			</p>

			<p>
				<b><u>Ingingo ya 2 :</u></b> Kuri iyi ngurane umunywanyi ahawe , yiyemeje gutanga ingwati zikurikira : canke yishinzwe na 
				<b><span class="client_name">.........(izina ryuwumzishinze).</span></b>
			</p>

			<p>
				<b><u>Ingingo ya 3</u>:</b>
				Humvikanwe kumpande zose ko umunywanyi azoruha mu buryo bukurikira : <br>

				<ul>
					<li>Amafaranga ya dosiye angana n'ibice ....(montant en %)  kw'ijana vy'amafaranga ahawe arihwa akiyahabwa </li>
					<li>
						Inyungu n'amafaranga .......... y'amarundi mu kiringo kingana n'amezi ....(Nombre de mois ) ....
					</li>

					<li>Ayazorihwa kukwezi/ kundwi zibiri angana .......</li>

				</ul>
			</p>

			<p>
				<b>Ingingo ya 4 :</b>
				Iyi ngurane itanzwe hisunzwe itegeko inomero 001/2018 rya Banki nkuru y'igihugu rigenga ibikorwa vy'amashirahamwe yo kuziganya no kuguranana mu Burundi ,hamwe n'itegeko inomero 1/17 ryo kuwa 22/08/2017 rigenga ama banki mu Burundi , n'amategeko agenga ikigega co kuziganya no kuguranana COOPDI uyu munywanyi asanzwe afisemwo ikonti akaba anayazi yose .
			</p>
			<p>
				<b><u>Ingingo ya 5: </u></b>
				Umunywanyi yiyemeje ko mugihe yoherana hazoca hafatwa ingingo zikurikira
				<br>
				<br>
				(..........................ingingo yiyemeje zose)
				<br><br>
			</p>

			<p>
				<b><u>Ingingo ya 6 :</u></b>Amatati yose aturutse mu nsiguro n'ikurikizwa ry'aya masezerano azoturza Sentare y'ubudandaji ya BUJUMBURA mugihe umwumvikano wonanirana hagati y'izo mpande zibiri .
			</p>

			<p><b><u>Ingingo ya 7 :</u></b>
				Aya masezerano ashizwe mungiro ataburyarya n'impande zose zemeye ikurikizwa n'ingaruka zayo, abo nabo bakaba ari : <br>

				<ul>
					<li>
						COOPDI isanwe ifise icicaro gikuru mu gisagara ca Bujumbura , mu Kinama kw'ibarabara rya mbere muri karitiye Muramvya
					</li>
					<li>
						N'umunyanyi wayo <b><span class="client_name">... (Izina ry'umunywanyi ) ....</span></b> aba ...(Izina ryoho aba) ..
					</li>
				</ul>
			</p>

			<p>
				<b><u>Ingingo ya 8 :</u></b> Umunywanyi asabwa gushira umukono kuri aya masezerano yo kwemeza ko yasomye ayamasezerano neza yitonze anayemejwe n'impande zose i Bujumbura kuwa ..../.../2020
			</p>

		</section>

		<footer class="footer">
			<table width="100%">
				<tr>
					<td width="50%">
						<b><u>Umunywanyi :</u></b> <span class="client_name"></span> <br>
						<b>Tél : </b> <b><span class="telephone">...............</span></b>

						<br>
						<b>CNI:</b> <b><span class="cni">.................</span></b>
						<br>
						<b>Umukono : </b>
						.................
						
					</td>
					<td width="50%">

						<b><u>Umukuru w'umutumba (Chef de quartier)</u></b>
						<br>
						<b>Amazina</b>
						........................ <br>
						<b>Tél:</b>................. <br>
						<b>Umukono:</b>
						...............
						
					</td>
				</tr>
				<tr>
					<td colspan ="2">
						<b><u>Uwushinzwe :</u></b>...................................
						<br>
						<b>Tél:</b>..........
						<br>
						<b>Umukono :</b>
						.............
					</td>
				</tr>
				<tr>
					<td>
						<b><u>Uwiga ingurane :</u></b>
						<br>..................................
					</td>

					<td style="text-align : center;">
						<p>
							Kubwa COOPDI

							<br>

							<h5>NDAYISHIMIYE Egide</h5>
						</p>
					</td>
				</tr>

				
			</table>
		</footer>


	</div>