@extends('layouts.app')
@section('content')

<div>
	<livewire:agence-livewire />
</div>

@endsection