@extends('layouts.app')

@section('content')

<div>
	<livewire:gestion-agence-livewire />
</div>

@endsection