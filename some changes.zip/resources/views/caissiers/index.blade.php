@extends('layouts.app')
@section('content')
<div>
	<livewire:caisse-caissier-livewire />
</div>
@endsection