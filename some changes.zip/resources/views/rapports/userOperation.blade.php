@extends('layouts.app')


@section('content')

<div class="container">
	<livewire:rapport-user />
	
</div>

@stop