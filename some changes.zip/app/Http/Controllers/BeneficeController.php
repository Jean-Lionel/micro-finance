<?php

namespace App\Http\Controllers;

use App\Models\Benefice;
use Illuminate\Http\Request;

class BeneficeController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Benefice  $benefice
     * @return \Illuminate\Http\Response
     */
    public function show(Benefice $benefice)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Benefice  $benefice
     * @return \Illuminate\Http\Response
     */
    public function edit(Benefice $benefice)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Benefice  $benefice
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Benefice $benefice)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Benefice  $benefice
     * @return \Illuminate\Http\Response
     */
    public function destroy(Benefice $benefice)
    {
        //
    }
}
